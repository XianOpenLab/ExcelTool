class CsvReadException(Exception):
    pass


class CancelSelectFileException(Exception):
    pass

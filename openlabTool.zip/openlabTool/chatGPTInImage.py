#!/usr/bin/env python
# -*- coding:gbk -*-
import openai

openai.api_key = "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"
input_str = '������'
print(input_str)
response = openai.Image.create(
    prompt=input_str,
    n=1,
    size="1024x1024"
)

image_url = response['data'][0]['url']
print(image_url)
